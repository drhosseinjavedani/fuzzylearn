# package version in pypi
__version__ = "1.1.0"
